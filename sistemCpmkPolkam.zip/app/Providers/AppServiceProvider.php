<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Blade;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {

    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        Blade::directive('activeClass', function ($route) {
            return "<?php echo request()->routeIs(" . var_export(trim($route, "'\""), true) . ")
        ? 'text-[#efb034]'
        : 'text-neutral-900 hover:text-neutral-900';
    ?>";
        });


    }
}
