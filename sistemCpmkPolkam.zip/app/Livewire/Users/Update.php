<?php

namespace App\Livewire\Users;

use Livewire\Component;
use App\Models\User;
use App\Models\UserRole;
class Update extends Component
{
    public $name, $email, $password;
    public $role = [];
    public $listRoles = [];

    public function mount($userId)
    {
        $user = User::find($userId);

        $this->name = $user?->name;
        $this->email = $user?->email;

        // Konversi role array -> boolean map
        foreach ($user->roles->pluck('id')->toArray() as $id) {
            $this->role[$id] = true;
        }

        $this->listRoles = UserRole::all();
    }


    public function update()
    {
        // $user = User::find($this->id);
        // $user->update([
        //     'name' => $this->name,
        //     'email' => $this->email,
        //     'password' => bcrypt($this->password),
        // ]);
        // $user->roles()->sync($this->role);
        // $this->dispatch('updated');
    }
    public function render()
    {
        return view('pages.users.update');
    }
}
