<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" class="dark">

<head>
    @include('partials.head')
    {{-- <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script> --}}
    @livewireStyles
</head>

<body class="min-h-screen bg-white dark:bg-zinc-800">
    <x-layouts.topbar />

    <x-layouts.navbar />


    {{ $slot }}
    @fluxScripts
    @livewireScripts
</body>

</html>
