<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="dark">

<head>
    <?php echo $__env->make('partials.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

</head>

<body class="min-h-screen bg-white dark:bg-zinc-800">
    <?php if (isset($component)) { $__componentOriginal5f954b3ba4e7a1a392c014525a6ffa48 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5f954b3ba4e7a1a392c014525a6ffa48 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.topbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.topbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5f954b3ba4e7a1a392c014525a6ffa48)): ?>
<?php $attributes = $__attributesOriginal5f954b3ba4e7a1a392c014525a6ffa48; ?>
<?php unset($__attributesOriginal5f954b3ba4e7a1a392c014525a6ffa48); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5f954b3ba4e7a1a392c014525a6ffa48)): ?>
<?php $component = $__componentOriginal5f954b3ba4e7a1a392c014525a6ffa48; ?>
<?php unset($__componentOriginal5f954b3ba4e7a1a392c014525a6ffa48); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginala9b3e504c250665e0a13110a708b1bba = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala9b3e504c250665e0a13110a708b1bba = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala9b3e504c250665e0a13110a708b1bba)): ?>
<?php $attributes = $__attributesOriginala9b3e504c250665e0a13110a708b1bba; ?>
<?php unset($__attributesOriginala9b3e504c250665e0a13110a708b1bba); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala9b3e504c250665e0a13110a708b1bba)): ?>
<?php $component = $__componentOriginala9b3e504c250665e0a13110a708b1bba; ?>
<?php unset($__componentOriginala9b3e504c250665e0a13110a708b1bba); ?>
<?php endif; ?>


    <?php echo e($slot); ?>

    <?php app('livewire')->forceAssetInjection(); ?>
<?php echo app('flux')->scripts(); ?>

    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

</body>

</html>
<?php /**PATH /var/www/html/resources/views/components/layouts/app/header.blade.php ENDPATH**/ ?>